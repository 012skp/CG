# Go into 14CS01038 directory
cd 14CS01038

# Build the Project.
$ make

# Run the progarm.
# There are three input files 'intput', 'intput1', 'input2'. Run with any..
./a input1


# Check the teminal to see face graph. Which cycle is connected to which cycle.
# Every connected component represents a face.
# There is a red colored cycle in every connected component.
# Every red colored cycles are inner_cycles and represents a FACE.
